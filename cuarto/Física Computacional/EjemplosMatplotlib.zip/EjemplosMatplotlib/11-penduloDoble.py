# -*- coding: utf-8 -*-
"""
Pendulo doble y movimiento caotico
https://nbviewer.jupyter.org/urls/www.numfys.net/media/notebooks/double_pendulum.ipynb
"""


import numpy as np
import matplotlib.pyplot as plt
from scipy.integrate import odeint
from matplotlib import animation

def penduloDoble(z, t, L1, L2, m1, m2, g):
    theta1, omega1, theta2, omega2 = z
    c12 = np.cos(theta1-theta2)
    s12 = np.sin(theta1-theta2)
    s1 = np.sin(theta1)
    s2 = np.sin(theta2)
    xi = c12**2*m2 - m1 - m2
    return [omega1, 
            (L1*m2*c12*s12*omega1**2+L2*m2*s12*omega2**2-m2*g*c12*s2+(m1+m2)*g*s1)/(L1*xi),
            omega2,
            -(L2*m2*c12*s12*omega2**2+L1*(m1+m2)*s12*omega1**2+(m1+m2)*g*s1*c12-(m1+m2)*g*s2)/(L2*xi)]


def aCartesianas(theta1, omega1, theta2, omega2, L1, L2):
    x1 = L1*np.sin(theta1)
    y1 = -L1*np.cos(theta1)
    x2 = x1 + L2*np.sin(theta2)
    y2 = y1 - L2*np.cos(theta2)
    vx1 = -y1*omega1
    vy1 = x1*omega1
    vx2 = vx1 + L2*np.cos(theta2)*omega2
    vy2 = vy1 + L2*np.sin(theta2)*omega2
    return x1, y1, x2, y2, vx1, vy1, vx2, vy2
  

L1 = 1.
m1 = 3.
m2 = 1.
L2 = 2.
g = 9.8

z0 = [np.pi/2, 0., np.pi/2, 0.]
t = np.linspace(0, 50, 1001)
sol = odeint(penduloDoble, z0, t, args=(L1, L2, m1, m2, g))
theta1 = sol[:, 0]
omega1 = sol[:, 1]
theta2 = sol[:, 2]
omega2 = sol[:, 3]
x1, y1, x2, y2, vx1, vy1, vx2, vy2 = aCartesianas(theta1, omega1, theta2, omega2, L1, L2)

L = (L1+L2)*1.1
plt.subplot(2,2,2)
plt.plot(t, sol[:, 0], c='b', label='$\\theta_1 (t)$')
plt.plot(t, sol[:, 2], c='black', label='$\\theta_2 (t)$')
plt.legend(loc='best')
plt.xlabel('$t$')
plt.grid()
plt.subplot(2,2,4)
plt.plot(t, sol[:, 1], c='g', label='$\\omega_1 (t)$')
plt.plot(t, sol[:, 3], c='r', label='$\\omega_2 (t)$')
plt.legend(loc='best')
plt.xlabel('$t$')
plt.grid()
plt.subplot(1,2,1)
plt.xlim(-L, L)
plt.ylim(-L, L)
plt.xlabel('$x$')
plt.ylabel('$y$')
plt.plot([0, L1, L1+L2], [0, 0, 0], 'o-', c='black', lw=2, label='Posicion inicial')
plt.plot(x1, y1, label='Trayectoria 1')
plt.plot(x2, y2, label='Trayectoria 2')
plt.legend()
plt.show()

plt.figure()
plt.title("Espacio de fases")
plt.plot(theta1, omega1, label='Masa 1')
plt.plot(theta2, omega2, label='Masa 2')
plt.legend()
plt.show()


fig = plt.figure()
ax = plt.axes(xlim=(-L, L), ylim=(-L, L))
line, = ax.plot([], [], 'o-', c='black', lw=3)

def init():
    line.set_data([], [])
    return line,

def animate(i):
    line.set_data([0, x1[i], x2[i]], [0, y1[i], y2[i]])
    return line,

anim = animation.FuncAnimation(fig, animate, init_func=init,
                               frames=1001, interval=50, blit=True)

plt.show()
