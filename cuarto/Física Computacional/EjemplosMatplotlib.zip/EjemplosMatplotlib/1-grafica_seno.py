# -*- coding: utf-8 -*-
"""
Created on Thu Mar 17 17:10:13 2016

@author: Jorge
"""

import numpy as np
import matplotlib.pyplot as plt

def f(x):
    return np.sin(x)

#crear el array de puntos en los que se va a evaluar la función (eje x)
valoresX = np.linspace(-2*np.pi, 2*np.pi, 100) 

#crear la figura
plt.figure()    #opcional si sólo hay una figura

#crea la gráfica, el segundo parámetro es la función a graficar, 
#puede ser cualquiera, también una definida por el usuario
#u otro array de puntos con los valores y correspondientes a los valores x
valoresY = f(valoresX)
plt.plot(valoresX,valoresY,"b-") 

plt.axis([-2*np.pi,2*np.pi,-1,1]) #establece los ejes (opcional)
plt.xlabel('x')  #Etiqueta del eje x (opcional)
plt.ylabel('y = sen(x)') #etiqueta del eje y (opcional)
plt.title('Gráfica de ejemplo') #Título de la gráfica (opcional)

plt.savefig('graficaSeno.png') #Si quiero guardar la figura en un archivo

plt.show()
