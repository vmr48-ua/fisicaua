"""
Descripción: Doble gráfica senoidal donde se muestran la mayoría de los complementos
que se pueden añadir a una gráfica
"""
import numpy as np
import matplotlib.pyplot as plt

# Definimos el periodo de la función
periodo = 0.5
# Definimos el array de las abcisas
x = np.linspace(0, 2, 1000)
# Definimos la función senoidal (creamos el array de ordenadas)
y = np.sin(2*np.pi*x/periodo)
# Creamos la figura
plt.figure()
# Dibujamos en negro discontinuo con etiqueta y1
plt.plot(x, y, 'k--', linewidth = 2, label = '$y_1$')
# Mantenemos la misma figura para la siguiente gráfica
# plt.hold(True)  #deprecated
# Esta vez dibujamos - y en rojo con etiqueta y2
plt.plot(x,-y,'r', linewidth = 2, label = '$y_2$')
# Añadimos la leyenda
plt.legend(loc = 2)  # posibles valores: 0, 1, 2, 3, best
# Añadimos las etiquetas poniendo con Latex "mu" símbolo de micras
plt.xlabel("$x (\mu m)$", fontsize = 24, color = (1,0,0))
plt.ylabel("$y (\mu m)$", fontsize = 24, color = 'blue')
# Añadimos texto (la posición en unidades de las variables)
plt.text(x = 1, y = 0.0, s = u'T = 0.05', fontsize = 24)
# Añadimos la rejilla
plt.grid(True)
plt.grid(color = '0.5', linestyle = '--', linewidth = 1)
# Añadimos los ejes
plt.axis('tight')
# Añadimos el título
plt.title('(a)',fontsize = 28, color = '0.75', verticalalignment = 'baseline', horizontalalignment='center')
# Guardamos
plt.savefig('plotCompleta.png')
# Mostramos en pantalla
plt.show()
