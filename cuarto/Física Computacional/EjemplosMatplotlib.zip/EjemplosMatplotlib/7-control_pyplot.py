import matplotlib.pyplot as plt
import numpy as np

fig = plt.figure()
ax = fig.add_subplot(211)
t = np.arange(0.0, 1.0, 0.01)
s = np.sin(2*np.pi*t)
line, = ax.plot(t, s, color='b', lw=2)
line1, = ax.plot(t, -s, 'k-.')
ax1 = fig.add_subplot(212)
ax1.scatter(np.random.randn(20), np.random.randn(20))

fig2 = plt.figure()
ax2 = fig2.add_axes([0, 0, 1, 1])
#ax2 = fig2.add_subplot(111)
n, bins, patches = ax2.hist(np.random.randn(1000), 50)
ax3 = fig2.add_axes([0.05, 0.7, 0.4, 0.2])
ax3.plot([1, 2, 3, 4], 'yo')


plt.show()




