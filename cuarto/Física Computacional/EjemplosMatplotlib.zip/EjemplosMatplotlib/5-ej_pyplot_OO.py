import matplotlib.pyplot as plt
import numpy as np

# Tres figuras diferentes para analizar algunas opciones

# Figura 1
fig = plt.figure() # Crear la figura y guardar una referencia a ella
ax = fig.add_subplot(211) # añadimos unos ejes y guardamos su referencia
t = np.arange(0.0, 1.0, 0.01)
s = np.sin(2*np.pi*t)
line, = ax.plot(t, s, color='b', lw=2) # Dibujamos una grafica y guardamos una referencia
line1, = ax.plot(t, -s, 'k-.') # Otra grafica con su referencia
ax1 = fig.add_subplot(212) # Otros ejes
ax1.scatter(np.random.randn(20), np.random.randn(20)) # otro tipo de grafica

# Figura 2
fig2 = plt.figure()
ax2 = fig2.add_axes([0, 0, 1, 1]) # Otra forma de crear ejes en posicion arbitraria
#ax2 = fig2.add_subplot(111)
n, bins, patches = ax2.hist(np.random.randn(1000), 50) # Un histrograma
ax3 = fig2.add_axes([0.05, 0.7, 0.4, 0.2]) # Otros ejes en posicion arbitraria
ax3.plot([1, 2, 3, 4], 'yo')


# Figura 3
# Mostramos como modificar detalles de todos los elementos de la grafica
plt.figure()
x = np.linspace(-np.pi, np.pi, 100)
cos = np.cos(x)
sin = np.sin(x)
plt.plot(x, cos, 'b')
plt.plot(x, sin, 'r')
# modificamos ejes y etiquetas del eje x
ax4 = plt.gca() # GetCurrentAxes
ax4.spines['right'].set_color('none')  #desaparece el eje derecho
ax4.spines['top'].set_color('none') #desparece el eje superior
ax4.xaxis.set_ticks_position('bottom') #desaparecen los ticks del eje superior
ax4.spines['bottom'].set_position(('data', 0)) #movemos el eje de x a la posicion del valor y=0
ax4.yaxis.set_ticks_position('left') #desaparecen los ticks del eje derecho
ax4.spines['left'].set_position(('data', 0)) #movemos el eje y a la posicion x=0
# cambiamos el aspecto de las etiquetas
plt.xlim(x.min()*1.1, x.max()*1.1)
plt.xticks([-np.pi, -np.pi/2, 0, np.pi/2, np.pi], \
           ['$-\pi$', '$-\pi/2$', '$0$', '$\pi/2$', '$\pi$'])
plt.ylim(cos.min()*1.1, cos.max()*1.1)
plt.yticks([-1, 0, 1], [-1, 0, 1])

 
plt.show()




