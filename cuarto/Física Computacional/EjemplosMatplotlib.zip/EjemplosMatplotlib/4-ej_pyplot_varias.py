import numpy as np
import matplotlib.pyplot as plt

periodo = 2
x = np.linspace(0, 10, 1000)
y = np.sin(2*np.pi*x/periodo)

plt.figure(1)
plt.subplot(2, 1, 1)
plt.plot(x, y, 'g')
plt.subplot(2, 2, 3)
plt.plot(x, y, 'b')
plt.subplot(2, 2, 4)
plt.plot(x, y, 'r')


plt.figure(2)
plt.subplot(1, 2, 1)
plt.hist(np.random.randn(1000), 50)
plt.subplot(1, 2, 2)
plt.scatter(np.random.randn(20), np.random.randn(20))
#Ejercicio: arreglar los ticks del eje x 
plt.xticks(())
plt.xticks((-2, -1, 0, 1, 2))


plt.show()
