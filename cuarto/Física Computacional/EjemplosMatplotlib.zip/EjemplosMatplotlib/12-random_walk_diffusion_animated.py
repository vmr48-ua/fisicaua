import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
import random

fig, ax = plt.subplots()
line, = plt.plot([], [], 'ro', animated=True)

# Iniciar el grafico
atoms = np.ones((400,2))*100

# Configuracion inicial
def init():
    line, = plt.plot(atoms[:, 0], atoms[:, 1], 'ro')
    ax.set_xlim(0, 200)
    ax.set_ylim(0, 200)
    return line,

# Actualizacion de cada frame
def update(frame):
    for j in range(400): # Para cada atomo de la gota
        # Lo movemos (o no) en direccion x e y
        atoms[j, 0] += random.randint(-1, 1)
        atoms[j, 1] += random.randint(-1, 1)
    # Comprobamos rebotes
    atoms[atoms == 200] = 198
    atoms[atoms == 0] = 2
    # Actualizamos la figura despues del paso
    line.set_xdata(atoms[:, 0])
    line.set_ydata(atoms[:, 1])
    return line,
    

ani = FuncAnimation(fig, update, 
                    init_func=init, blit=True, interval=20)
plt.show()
